$(function() {

	$('.inner_table table.adaptive').stacktable();

});
